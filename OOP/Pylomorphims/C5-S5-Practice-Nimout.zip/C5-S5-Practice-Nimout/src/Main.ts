
import { Color } from "./Color";
import { Word } from "./Word";


let ronan = new Word('ronan',false,Color.GREEN);


console.log(ronan.getCode());

