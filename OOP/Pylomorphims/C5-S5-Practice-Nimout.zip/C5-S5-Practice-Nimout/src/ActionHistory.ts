
// class ActionHistory{
//     private redos: 
//     private undos: 
//     do(action: Action){
        
//     }
//     undo():void{}
// }