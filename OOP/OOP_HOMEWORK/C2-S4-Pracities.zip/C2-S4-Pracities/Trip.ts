import { Address } from "./address";
import { Customer } from "./customer";
export class Trip{
    busName: string;
    customer : Customer[] = [];
    departurePlace?: Address ;
    arrivalPlace? : Address ;
    constructor(busName: string){
        this.busName = busName;
    }
    
}