"use strict";
exports.__esModule = true;
var address_1 = require("./address");
var customer_1 = require("./customer");
var trip_1 = require("./trip");
//ADDDRESS
var france = new address_1.Address("Paris", "France");
var phnomPenh = new address_1.Address("Phnom Penh", "Cambodia");
var kampot = new address_1.Address("Kampot", "Cambodia");
var sieamReap = new address_1.Address("Sieam Reap", "Cambodia");
//CUSTOMER
var ronan = new customer_1.Customer("Ronan", "Ogor");
var him = new customer_1.Customer("Him", "Hey");
var sovanda = new customer_1.Customer("Sovanda", "Chib");
///KAKA Trip
var kakaBus = new trip_1.Trip("KAKA Bus");
kakaBus.departurePlace = phnomPenh;
kakaBus.arrivalPlace = kampot;
kakaBus.customer.push(him, sovanda);
///LYHOR Trip
var lyhorExpress = new trip_1.Trip("LYHOR Express");
lyhorExpress.departurePlace = phnomPenh;
lyhorExpress.arrivalPlace = sieamReap;
lyhorExpress.customer.push(him, sovanda, ronan);
console.log(lyhorExpress);
console.log(kakaBus);
