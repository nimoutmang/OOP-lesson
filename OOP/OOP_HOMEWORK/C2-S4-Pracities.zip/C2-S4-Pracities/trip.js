"use strict";
exports.__esModule = true;
exports.Trip = void 0;
var Trip = /** @class */ (function () {
    function Trip(busName) {
        this.customer = [];
        this.busName = busName;
    }
    return Trip;
}());
exports.Trip = Trip;
