// Instructions:
// • Add type annotations (as explicit as possible)
// • Fix errors (if applicable)
var value1 = 6;
var value2 = 6.66;
var value3 = Number.MAX_VALUE;
var allValues = [value1, value2, value3];
allValues[0] = 12345;
console.log(allValues);
