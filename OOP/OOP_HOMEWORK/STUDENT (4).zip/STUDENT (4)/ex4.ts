// Instructions:
// • Add type annotations (as explicit as possible)
// • Fix errors (if applicable)

const value1 = 6;
const value2 = 6.66;
const value3 = Number.MAX_VALUE;

const allValues = [value1, value2, value3];

allValues[0] = "12345";

console.log("[Exercise 1.4]", members);
