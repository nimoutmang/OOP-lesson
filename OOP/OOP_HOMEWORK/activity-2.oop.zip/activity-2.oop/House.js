"use strict";
exports.__esModule = true;
exports.House = void 0;
var House = /** @class */ (function () {
    function House(name) {
        this.room = [];
        this.door = [];
        this.name = name;
    }
    return House;
}());
exports.House = House;
