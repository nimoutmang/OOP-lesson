"use strict";
exports.__esModule = true;
exports.Door = void 0;
var Door = /** @class */ (function () {
    function Door(color) {
        this.color = color;
    }
    return Door;
}());
exports.Door = Door;
