"use strict";
exports.__esModule = true;
exports.Resource = void 0;
var Resource = /** @class */ (function () {
    function Resource() {
    }
    return Resource;
}());
exports.Resource = Resource;
