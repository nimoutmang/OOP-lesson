export abstract class Resource {
    abstract getName(): string | null;
}